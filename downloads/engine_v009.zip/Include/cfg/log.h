#pragma once
void PElogger(const char* message);
void PElogger_up(const char* message);
